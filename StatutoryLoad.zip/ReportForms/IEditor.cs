﻿using System;

namespace ReportForms
{
    public interface IEditor
    {
        event EventHandler Applied;
    }
}